app.controller("inspirationCtrl", function ($scope, $css) {
//  $scope.count = 123;

    $css.removeAll();
    $css.add('./inspiration/css/inspiration.css');
});
