app.controller("caseCtrl", function ($scope, $css) {

    $css.removeAll();
    $css.add('./case/css/case.css');
});
