app.controller("diaryCtrl", function ($scope, $css) {

    $css.removeAll();
    $css.add('./diary/css/diary.css');
});
